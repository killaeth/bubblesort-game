import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Arrays;
import java.util.Random;

public class BubbleSortJogo extends JFrame {

    private int[][] matriz;
    private DefaultTableModel tableModel;
    private int selectedLin = -1;
    private int selectedCol = -1;

    public BubbleSortJogo() {
        setTitle("Jogo com BubbleSort");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 400);
        setLocationRelativeTo(null);
        setResizable(false);

        matriz = new int[5][5];
        Random random = new Random();

        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[i].length; j++) {
                matriz[i][j] = random.nextInt(100);
            }
        }

        tableModel = new DefaultTableModel(matriz.length, matriz[0].length) {
            @Override
            public boolean isCellEditable(int lin, int col) {
                return false;
            }
        };
        JTable table = new JTable(tableModel);

        table.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int lin, int col) {
                Component component = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, lin, col);
                component.setBackground(Color.WHITE);
                return component;
            }
        });

        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[i].length; j++) {
                tableModel.setValueAt(matriz[i][j], i, j);
            }
        }

        table.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                int lin = table.rowAtPoint(e.getPoint());
                int col = table.columnAtPoint(e.getPoint());

                if (isValidMove(lin, col)) {
                    selectedLin = lin;
                    selectedCol = col;
                }
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                int lin = table.rowAtPoint(e.getPoint());
                int col = table.columnAtPoint(e.getPoint());

                if (selectedLin != -1 && selectedCol != -1 && lin != -1 && col != -1 && isValidMove(lin, col)) {
                    int temp = matriz[lin][col];
                    matriz[lin][col] = matriz[selectedLin][selectedCol];
                    matriz[selectedLin][selectedCol] = temp;
                    tableModel.setValueAt(matriz[lin][col], lin, col);
                    tableModel.setValueAt(matriz[selectedLin][selectedCol], selectedLin, selectedCol);

                    if (isSorted()) {
                        JOptionPane.showMessageDialog(BubbleSortJogo.this, "Parabéns! A matriz está ordenada!");
                    }
                }

                selectedLin = -1;
                selectedCol = -1;
            }
        });

        setLayout(new BorderLayout());
        add(new JScrollPane(table), BorderLayout.CENTER);

        setVisible(true);
    }

    private boolean isValidMove(int lin, int col) {
        if (selectedLin == -1 || selectedCol == -1) {
            return true;
        }

        return (Math.abs(lin - selectedLin) <= 1 && col == selectedCol)
                || (Math.abs(col - selectedCol) <= 1 && lin == selectedLin);
    }

    private boolean isSorted() {
        int[] flatArray = Arrays.stream(matriz)
                .flatMapToInt(Arrays::stream)
                .toArray();

        int[] sortedArray = Arrays.copyOf(flatArray, flatArray.length);
        Arrays.sort(sortedArray);

        return Arrays.equals(flatArray, sortedArray);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(BubbleSortJogo::new);
    }
}
