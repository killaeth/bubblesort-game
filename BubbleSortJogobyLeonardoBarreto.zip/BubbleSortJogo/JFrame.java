public interface JFrame {
}
