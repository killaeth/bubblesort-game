Olá! A mecânica do jogo consiste em arrastar o número até o que você quer trocar de posição. 
Não basta clicar em um e em outro, tem que arrastar um ao outro para poder jogar. 